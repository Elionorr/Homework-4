package homework4;

public class Rectangle {
	private double height;
	private double width;
	public static final int maxHeight;
	public static final int maxWidth;
	
	static {
		maxHeight = 20;
		maxWidth = 40;
	}

	public void setWidth(double width) {
		if(width <= maxWidth) {
			this.width = width;
		}else {
			this.width = maxWidth;
		}
	}
	
	public void setHeight(double height) {
		if(height <= maxHeight) {
			this.height = height;
		}else {
			this.height = maxHeight;
		}
	}
	 
	public Rectangle(double width, double height) {
	        setWidth(width);
	        setHeight(height);
	    }
	
	public double computeArea() {
		return this.width * this.height;
	}
	
	public static Rectangle maxArea(Rectangle[] rectArray) {
		Rectangle maxArea = rectArray[0];
		for (int i = 0; i < rectArray.length; i++){
            if(rectArray[i].computeArea()>maxArea.computeArea()){
                maxArea = rectArray[i];
            }
        }
        return maxArea;
    }
}
