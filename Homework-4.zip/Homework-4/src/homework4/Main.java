package homework4;

public class Main {

	public static void main(String[] args) {
		Rectangle rectangle1 = new Rectangle(50, 70);
		
		Rectangle rectangle2 = new Rectangle(10, 25);
		
		Rectangle rectangle3 = new Rectangle(20, 45);
		
		Rectangle rectangle4 = new Rectangle(30, 15);
		
		Rectangle[] rectArray = {rectangle1, rectangle2, rectangle3, rectangle4};
		
		//System.out.println("Width = " + rectangle.maxWidth + ". " + "Height = " + rectangle.maxHeight + ". " + "Area = " + rectangle.computeArea());
		System.out.println("There is rectangle array and in this array there are four rectangle.\n"
				+ "The area of each rectangles is: \n" + "Firt rectangle's area = " + rectArray[0].computeArea() + 
				"\nSecond rectangle's area = " + rectArray[1].computeArea() + 
				"\nThird rectangle's area = " + rectArray[2].computeArea() +
				"\nFourth rectangle's area = " + rectArray[3].computeArea() + 
				"\nFrom these rectangle's, the largest(maximum) rectangle's area is -> " + Rectangle.maxArea(rectArray).computeArea());
	}

}
